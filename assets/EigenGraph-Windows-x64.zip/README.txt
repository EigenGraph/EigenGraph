============================================================
 EigenGraph — High-Performance 10D BIM & Structural Analytics
 Platform: Windows x64 (Windows 10 / Windows 11)
 Version:  v0.1.0
============================================================

Quick Start Instructions:
1. Extract all contents of this ZIP archive to your preferred directory.
2. Double-click 'eigengraph.exe' to launch the desktop workstation.
3. The parametric component database and InternalVault synchronize
   automatically in real time.

Documentation & Releases: https://github.com/EigenGraph/EigenGraph
