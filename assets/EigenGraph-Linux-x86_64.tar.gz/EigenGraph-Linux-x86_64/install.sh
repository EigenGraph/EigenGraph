#!/usr/bin/env bash
set -e
INSTALL_BIN="${HOME}/.local/bin"
DESKTOP_DIR="${HOME}/.local/share/applications"
ICON_DIR="${HOME}/.local/share/icons/hicolor/256x256/apps"
mkdir -p "$INSTALL_BIN" "$DESKTOP_DIR" "$ICON_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/eigengraph" "$INSTALL_BIN/"
chmod +x "$INSTALL_BIN/eigengraph"
if [ -f "$SCRIPT_DIR/assets/icon.png" ]; then
  cp "$SCRIPT_DIR/assets/icon.png" "$ICON_DIR/eigengraph.png"
fi
sed "s|Exec=eigengraph|Exec=$INSTALL_BIN/eigengraph|g" "$SCRIPT_DIR/eigengraph.desktop" > "$DESKTOP_DIR/eigengraph.desktop"
sed -i "s|Icon=eigengraph|Icon=$ICON_DIR/eigengraph.png|g" "$DESKTOP_DIR/eigengraph.desktop"
echo "✅ EigenGraph installed successfully to $INSTALL_BIN/eigengraph"
echo "Launch it from your application menu or run eigengraph in terminal."
